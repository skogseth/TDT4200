nsys profile ./morph images/man9.jpg images/man10.jpg lines/lines-man9-man10.txt output-png/ 2
